
<?php require_once("_incs/header.php");?>
  <!--div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <br><br>
        <h1 class="header center teal-text text-lighten-2">&nbsp;</h1>
        <div class="row center">
          <h5 class="header col s12 light">&nbsp;</h5>
        </div>
        <div class="row center">
         &nbsp;
        </div>
        <br><br>

      </div>
    </div>
    <div class="parallax"><img src="< ?php echo $base_url;?>assets/_imagens/slider1.png" alt="Unsplashed background img 1"></div>
  </div-->


  <div class="container">
    <div class="section">

      <!--   Icon Section   -->
      <div class="row">
          <div class="col s12 m3">
              <div class="card">
                <div class="card-image">
                  <img src="assets/_imagens/banner_diagnostico.png">
                  <span class="card-title" style="color:#135e7b">Diagnóstico Product Owner</span>
                </div>
                <div class="card-content">
                  <p>Texto explicativo</p>
                </div>
                <div class="card-action">
                  <a href="cria_diagnostico.php?tipo=1">Crie agora</a>
                </div>
              </div>
        </div>
        <div class="col s12 m3">
              <div class="card">
                <div class="card-image">
                  <img src="assets/_imagens/banner_diagnostico.png">
                  <span class="card-title" style="color:#135e7b">Diagnóstico de Maturidade do Scrum</span>
                </div>
                <div class="card-content">
                  <p>Texto explicativo</p>
                </div>
                <div class="card-action">
                  <a href="cria_diagnostico.php?tipo=2">Crie agora</a>
                </div>
              </div>
        </div>

                  <div class="col s12 m3">
              <div class="card">
                <div class="card-image">
                  <img src="assets/_imagens/banner_diagnostico.png">
                  <span class="card-title" style="color:#135e7b">Diagnóstico de Maturidade do Management 3.0</span>
                </div>
                <div class="card-content">
                  <p>Texto explicativo.</p>
                </div>
                <div class="card-action">
                  <a href="#">Em breve</a>
                </div>
              </div>
        </div>

                  <div class="col s12 m3">
              <div class="card">
                <div class="card-image">
                  <img src="assets/_imagens/banner_diagnostico.png">
                  <span class="card-title" style="color:#135e7b">Diagnóstico de Maturidade do SAFe</span>
                </div>
                <div class="card-content">
                  <p>Texto explicativo.</p>
                </div>
                <div class="card-action">
                  <a href="#">Em Breve</a>
                </div>
              </div>
        </div>
    </div>
    <br><br>
  </div>
</div>
<?php require_once("_incs/footer.php");?>