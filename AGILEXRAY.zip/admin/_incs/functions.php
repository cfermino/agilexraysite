<?php



$diag_pai = array();

$diag_pai[1] = 'Diagnóstico de Product Manager/Product Owner';
$diag_pai[2] = 'Diagnóstico de Scrum';
$diag_pai[3] = 'Diagnóstico do Time';